package automationFramework;

import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

public class FirstTestCase {
	public static <WebElement> void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//WebDriver driver=new FirefoxDriver();

		
		System.getProperty("webdriver.gecko.driver", "C:\\Users\\Preetham Tavane\\Desktop\\ToolsQA\\OnlineStore\\geckodriver.exe");

        DesiredCapabilities capabilities = DesiredCapabilities.firefox();
        capabilities.setCapability("marionette", true);

        // Initialize WebDriver
        WebDriver driver = new FirefoxDriver(capabilities);
		
		driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3Fref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
		
		driver.findElement(By.xpath("//input[@id='ap_email']")).sendKeys("tavaneharish@gmail.com");;

		driver.findElement(By.xpath("//input[contains(@id,'continue')]")).click();
		
		driver.findElement(By.xpath("//input[contains(@id,'ap_password')]")).sendKeys("Preetu@2013");
		
		driver.findElement(By.xpath("//input[contains(@id,'signInSubmit')]")).click();
		
		driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("headphones");
		
		driver.findElement(By.xpath("//input[@value='Go']")).click();
		
		List<WebElement> elements = (List<WebElement>) driver.findElements(By.xpath("(//span[@class='a-badge-text'][contains(.,'Best seller')])"));
		
			for(int i=1;i<=elements.size();i++) {
				
			driver.findElement(By.xpath("//img[@data-image-index='"+i+"']")).click();
			
			// Store all currently open tabs in tabs
			 ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			 
			 // Click on link to open in new tab
			 ///driver.findElement(By.id("Url_Link")).click();
			 
			 // Switch newly open Tab
			 driver.switchTo().window(tabs.get(1));
			 
			 Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)							
						.withTimeout(30, TimeUnit.SECONDS) 			
						.pollingEvery(5, TimeUnit.SECONDS) 			
						.ignoring(NoSuchElementException.class);
				WebElement clickseleniumlink = wait.until(new Function<WebDriver, WebElement>(){
				
					public WebElement apply(WebDriver driver ) {
						return (WebElement) driver.findElement(By.xpath("//input[@id='add-to-cart-button']"));
					}
				});
			 //driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
				driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
				
			 // Perform some operation on Newly open tab
			 // Close newly open tab after performing some operations.
			 driver.close();
			 
			 // Switch to old(Parent) tab.
			 driver.switchTo().window(tabs.get(0));
			 
			//driver.findElement(By.xpath("//input[@id='add-to-cart-button']")).click();
			//driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"1");
			
			}
			
		driver.quit();

	}

}
